const axios = require('axios');
const fs = require('fs');
const path = require('path');

const cooldowns = {};

module.exports.config = {
	name: "الغرفة_الحمراء",
	version: "1.5.8",
	hasPermission: 2,
	credits: "Hazeyy",
	description: "( فيوهات من الغرفة الحمراء )",
	commandCategory: "المالك",
	usages: "( الغرفة_الحمراء )",
	cooldowns: 15, 
};

module.exports.handleEvent = async function ({ api, event }) {
	if (!(event.body.indexOf("redroomv2") === 0 || event.body.indexOf("Redroomv2") === 0)) return;

	const userId = event.senderID;
	if (cooldowns[userId] && Date.now() - cooldowns[userId] < module.exports.config.cooldowns * 1000) {
		const remainingTime = Math.ceil((cooldowns[userId] + module.exports.config.cooldowns * 1000 - Date.now()) / 1000);
		api.sendMessage(`🕦 هي هل أنت غبي ألا تراني أنني في وقت الانتظار [ ${remainingTime} ] ثانية,  `, event.threadID);
		return;
	}

	const args = event.body.split(/\s+/);
	args.shift();

	api.setMessageReaction("💽", event.messageID, (err) => {}, true);

	let url = "https://hazeyy-redroom-v2-api.kyrinwu.repl.co";

	try {
		api.sendMessage("📀 | جاري إرسال الفيديو...", event.threadID);

		let { data } = await axios.get(url + "/files");
		let getFiles = await axios.get(url + "/" + data.file, { responseType: "arraybuffer" });

		const randomFileName = `${Math.floor(Math.random() * 99999999)}${data.type}`;
		const filePath = path.join(__dirname, 'cache', randomFileName);

		fs.writeFileSync(filePath, Buffer.from(getFiles.data, 'binary'));

		const message = {
			body: "🎥 هاهو ذا الفيديو اللذي طلبته.",
			attachment: fs.createReadStream(filePath),
		}

		 api.sendMessage(message, event.threadID);

		cooldowns[userId] = Date.now();

		api.sendMessage("📬 | مذكر: 𝖳𝗁𝖾 سيتم إرسال الفيديو خلال بضع ثواني المرجو الإنتظار.", event.threadID);

	} catch (error) {
		console.error('🔴 حدث خطأ أثناء إرسال الفيديو', error);
		api.sendMessage('🔴 خطأ في إرسال الفيديو', event.threadID, event.messageID);
	}
};

module.exports.run = async function ({ api, event }) {

};