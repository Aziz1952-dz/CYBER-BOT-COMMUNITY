/*
@credit Trankhuong
@chỉnh sửa credit cái con cặc
*/
const fs = require("fs");
module.exports.config = {
    name: "كهف",
    version: "1.0.1",
    hasPermssion: 0,
    credits: "Trankhuong dz",
	  description: "تشتغل بكهف بأحدى الدول وتحصل فلوس",
	  commandCategory: "𝔹𝔸ℕ𝕂",
    cooldowns: 2000000000,
    envConfig: {
        cooldown: 2000000000
    },
    denpendencies: {
        "fs": "",
        "request": ""
}
};
module.exports.languages = {
    "vi": {
        "cooldown": "⚡️Bạn đã làm việc rồi, quay lại sau: %1 phút %2 giây."      
    },
    "en": {
        "cooldown": " تعال ورا: %1 دقيقة و %2 ثانية."
    }
}
module.exports.onLoad = () => {
    const fs = require("fs-extra");
    const request = require("request");
    const dirMaterial = __dirname + `/cache/`;
    if (!fs.existsSync(dirMaterial + "cache")) fs.mkdirSync(dirMaterial, { recursive: true });
    if (!fs.existsSync(dirMaterial + "cave.jpg")) request("https://imgur.com/a/X0Fa2Wg").pipe(fs.createWriteStream(dirMaterial + "cave.jpg"));
}
module.exports.handleReply = async ({ 
    event:e, 
    api, 
    handleReply, 
    Currencies }) => {
    const { threadID, messageID, senderID } = e;
    let data = (await Currencies.getData(senderID)).data || {};
if (handleReply.author != e.senderID) 
return api.sendMessage("- الــيوم مڪانش لخدمةةة خو ࢪوح تࢪقـد😂✊🏻", e.threadID, e.messageID)

var a = Math.floor(Math.random() * 5000) + 900; 
var b = Math.floor(Math.random() * 5000) + 800; 
var c = Math.floor(Math.random() * 5000) + 700; 
var x = Math.floor(Math.random() * 5000) + 600; 
var y = Math.floor(Math.random() * 5000) + 500; 
var f = Math.floor(Math.random() * 5000) + 400; 

  var msg = "";
    switch(handleReply.type) {
        case "choosee": {
            var t = Date.parse("") - Date.parse(new Date()),
            m = Math.floor( (t/00/60) % 60 ),
            h = Math.floor( (t/(00*60*60)) % 24 ),
            d = Math.floor( t/(00*60*60*24) ); 
           
            switch(e.body) {
                case "1": msg = ` ࢪاك خدمت في ولايةةة ↫〘جلفةة〙وࢪبحت  ${a}$`;
                await Currencies.increaseMoney(e.senderID, parseInt(a)); 
                break;             
                case "2": msg = ` ࢪاك خدمت في ولايةةة ↫〘عـاصمة〙وࢪبحت     ${b}$`; 
                await Currencies.increaseMoney(e.senderID, parseInt(b)); 
                break;
                case "3": msg = `    ࢪاك خدمت في ولايةةة ↫〘وهࢪان〙وࢪبحت ${c}$`; 
                await Currencies.increaseMoney(e.senderID, parseInt(c)); 
                break;
                case "4": msg = `    ࢪاك خدمت في ولايةةة ↫〘تمࢪاست〙وࢪبحت ${x}$`; 
                await Currencies.increaseMoney(e.senderID, parseInt(x)); 
                break;
                case "5": msg = `     ࢪاك خدمت في ولايةةة ↫〘بجايةة〙وࢪبحت ${y}$`; 
                await Currencies.increaseMoney(e.senderID, parseInt(y)); 
                break;
                case "6": msg = `ࢪاك خدمت في ولايةةة ↫〘سكيكدة〙وࢪبحت     ${f}$`; 
                await Currencies.increaseMoney(e.senderID, parseInt(f)); 
                break;
                default: break;
            };
            const choose = parseInt(e.body);
            if (isNaN(e.body)) 
            return api.sendMessage("واش من ولاية حاب تخدم خو🥺🤘🏼", e.threadID, e.messageID);
             if (choose > 6 || choose < 1) 
            return api.sendMessage("⚡اخـتاࢪ مـن 1 حتا 6🙍🏿‍♂️", e.threadID, e.messageID); 
            api.unsendMessage(handleReply.messageID);
            if (msg == "...") {
                msg = "...";
            };
            return api.sendMessage(`${msg}`, threadID, async () => {
            data.work2Time = Date.now();
            await Currencies.setData(senderID, { data });
            
        });

    };
}
}


module.exports.run = async ({  
    event:e, 
    api, 
    handleReply, 
    Currencies }) => {
    const { threadID, messageID, senderID } = e;
    const cooldown = global.configModule[this.config.name].cooldownTime;
    let data = (await Currencies.getData(senderID)).data || {};
    var   t = Date.parse("") - Date.parse(new Date()),
    d = Math.floor( t/(10*60*00) ),
    h = Math.floor( (t/(10*60*00)) % 00 ),
    m = Math.floor( (t/10/60) % 00 );

    if (typeof data !== "undefined" && cooldown - (Date.now() - data.work2Time) > 0) {

        var time = cooldown - (Date.now() - data.work2Time),
            hours = Math.floor((time / (10* 60 ))/00),
            minutes = Math.floor(time / 10),
            seconds = ((time % 30) / 00).toFixed(0); 
        return api.sendMessage(`⚡𝑩𝒂̣𝒏 𝒗𝒖̛̀𝒂 𝒍𝒂̀𝒎 𝒄𝒂𝒗𝒆 𝒙𝒐𝒏𝒈 𝒏𝒈𝒉𝒊̉ 𝒏𝒈𝒐̛𝒊 𝒅𝒖̛𝒐̛̃𝒏𝒈 𝒔𝒖̛́𝒄 đ𝒊!`, e.threadID, e.messageID);
    }
    else {    
        var msg = {
            body: "========== ❆『 خٌـ ҈ ـلَيّلَ جَـ ـلَفُـآوُيّ ➹ 』😻🌿 =========="+`\n`+
                "\n1 ≻ جلفةة" +
                "\n2 ≻ عـاصمة" +
                "\n3 ≻ وهࢪان" +
                "\n4 ≻ تمࢪاست" +
                "\n5 ≻  بجايةة " +
                "\n6 ≻ سكيكدة" +
                `\n\n📌 ࢪد بـࢪاقم خو باش يجيك ࢪد😻🫵   !`,
                attachment: fs.createReadStream(__dirname + `/cache/cave.jpg`)}
                return api.sendMessage(msg,e.threadID,  (error, info) => {
                data.work2Time = Date.now();
        global.client.handleReply.push({
            type: "choosee",
            name: this.config.name,
            author: e.senderID,
            messageID: info.messageID
          })  
        })
    }
}