module.exports.config = {
		name: "قفل",
		version: "1.0.0",
		credits: "DungUwU (Khánh Milo Fix)",
		hasPermssion: 1,
		description: "Turn off antiout",
		usages: "antiout on/off",
		commandCategory: "system",
		cooldowns: 0
};

module.exports.run = async({ api, event, Threads}) => {
		let data = (await Threads.getData(event.threadID)).data || {};
		if (typeof data["قفل"] == "undefined" || data["قفل"] == false) data["قفل"] = true;
		else data["قفل"] = false;

		await Threads.setData(event.threadID, { data });
		global.data.threadData.set(parseInt(event.threadID), data);

		return api.sendMessage(`✅ تم ${(data["قفل"] == true) ? "تشغيل القفل" : "إيقاف القفل"} بنجاح!`, event.threadID);

}