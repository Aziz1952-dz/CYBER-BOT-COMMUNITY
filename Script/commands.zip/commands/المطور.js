module.exports.config = {
	name: "المطور",
	version: "1.0.1", 
	hasPermssion: 0,
	credits: "Joshua Sy", //don't change the credits please
	description: "معلومات البوت و المطور",
	commandCategory: "𝔾ℝ𝕆𝕌ℙ",
	cooldowns: 1,
	dependencies: 
	{
    "request":"",
    "fs-extra":"",
    "axios":""
  }
};
module.exports.run = async function({ api,event,args,client,Users,Threads,__GLOBAL,Currencies }) {
const axios = global.nodemodule["axios"];
const request = global.nodemodule["request"];
const fs = global.nodemodule["fs-extra"];
const time = process.uptime(),
		hours = Math.floor(time / (60 * 60)),
		minutes = Math.floor((time % (60 * 60)) / 60),
		seconds = Math.floor(time % 60);
const moment = require("moment-timezone");
var juswa = moment.tz("Asia/Manila").format("『D/MM/YYYY』 【HH:mm:ss】");
var link = ["https://i.imgur.com/CUCRSI0.jpeg", "https://i.imgur.com/7ixvbQT.jpeg", "https://imgur.com/a/C1QwCNx", "https://i.imgur.com/J1dmLGr.png", "https://i.imgur.com/1uAvG3P.png", "https://i.imgur.com/GWz0HTl.jpeg", "https://imgur.com/a/l42t1y0", "https://i.imgur.com/wwXcBEN.jpeg"];
var callback = () => api.sendMessage({body:`︻︻︻︻︻︻︻︻︻︻︻︻︻︻︻︻︻︻
↫ ➹ 😿💋ُ〘✞ঔৣ خـليل.جلفاوي ঔৣ✞〙

نڪمي فلحࢪوف بࢪك....ꜝꜝ🥺💔ٕ 〘𝗞𝗛𝗔𝗟𝗜𝗟❆〙
‌‌          ‌      جـاك لخليل لقيدو...ꜝꜝ🫵😻


حــسابي لاسـاسي...↫[https://www.facebook.com/profile.php?id=100000155247632]


........نــمــوت عــليك ↫〘😾‼️〙.........    🥺
︼︼︼︼︼︼︼︼︼︼︼︼︼︼︼︼︼︼`,attachment: fs.createReadStream(__dirname + "/cache/juswa.jpg")}, event.threadID, () => fs.unlinkSync(__dirname + "/cache/juswa.jpg")); 
      return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname+"/cache/juswa.jpg")).on("close",() => callback());
   };